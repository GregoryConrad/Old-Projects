#include "includes.h"

class otherFunc {
public:
	std::string progressBar(int progressCheck);
	std::string getcwd_string( void );
	void setValuesVMode(bool a);
	void displayHelp();
private:
	bool verboseMode;
};