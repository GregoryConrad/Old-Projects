# AlbanianVirus
A harmless "virus", meant for humor

# Instructions
1. `npm install electron-prebuilt`
2. `npm start`
