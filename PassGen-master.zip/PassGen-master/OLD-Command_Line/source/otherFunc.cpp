//Includes:
#include "otherFunc.h"
#include "argFunctions.h"
//Functions:
std::string otherFunc::progressBar(int progressCheck) { //Returns how many |'s to print.
	std::string temp = "";
	for (int i = 0; i < progressCheck / 2; i++) {
		temp += "|";
	}
	return temp;
}
std::string otherFunc::getcwd_string( void ) {
   char buff[PATH_MAX];
   getcwd( buff, PATH_MAX );
   std::string cwd( buff );
   return cwd;
}
void otherFunc::displayHelp() {
	std::cout << "Dictionary File Generator\nUse for legal purposes only.\n"
			<< "While the program is running, hit Control-C to abort at any time.\n"
			<< "Options:\n"
			<< "  -h, -help       : Shows this help menu\n"
			<< "  -v              : Turns on verbose mode\n"
			<< "  -npb            : Doesn't display progress bar\n"
			<< "  -d <directory>  : Makes the password file in the given directory\n" 
			<< "  -pl <number>    : Sets the password length (has to be between 1 and 20)\n"
			<< "  -c <characters> : Sets the characters that are used in the generation\n"
			<< "  -f <fileName>   : Sets the dictionary file name to fileName\n"
			<< "If no options are given, this help menu is displayed.\n-pl is a required flag.\n";
}
void otherFunc::setValuesVMode(bool a) {
	verboseMode = a;
}