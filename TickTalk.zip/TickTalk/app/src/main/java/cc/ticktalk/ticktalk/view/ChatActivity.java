package cc.ticktalk.ticktalk.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.gsconrad.richcontentedittext.RichContentEditText;
import com.gsconrad.slidedetector.SlideDetector;

import java.io.File;

import cc.ticktalk.ticktalk.R;
import cc.ticktalk.ticktalk.model.Utilities;
import cc.ticktalk.ticktalk.view_model.ChatActivityViewModel;
import de.hdodenhof.circleimageview.CircleImageView;

public class ChatActivity extends AppCompatActivity {
    private static final String TAG = "ChatActivity";
    private static final int CAMERA_REQUEST = 1;
    private static final int PICTURE_REQUEST = 2;
    private static final int FILE_REQUEST = 3;
    private ChatActivityViewModel viewModel;
    private RecyclerView messageList;
    private CardView composer;
    private RichContentEditText messageText;
    private Button attachmentButton;
    private CardView attachmentPicker;
    private ConstraintLayout attachmentPreview;
    private int attachmentPreviewHeight;

    class MessageViewHolder extends RecyclerView.ViewHolder {
        ConstraintLayout layout;
        CardView hiddenInfoHolder;
        CircleImageView picture;
        CardView messageWrapper;
        TextView messageText, messageTime, messageSender;

        MessageViewHolder(View itemView) {
            super(itemView);
            layout = itemView.findViewById(R.id.chat_item_message_layout);
            hiddenInfoHolder = itemView.findViewById(R.id.chat_item_message_hidden_info_holder);
            picture = itemView.findViewById(R.id.chat_item_message_picture);
            messageWrapper = itemView.findViewById(R.id.chat_item_message_wrapper);
            messageText = itemView.findViewById(R.id.chat_item_message_text);
            messageTime = itemView.findViewById(R.id.chat_item_message_time);
            messageSender = itemView.findViewById(R.id.chat_item_message_sender);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        viewModel = ViewModelProviders.of(this).get(ChatActivityViewModel.class);
        setupToolbar();
        setupMessageList();
        setupAttachmentPreview();
        setupAttachmentPicker();
        setupMessageText();
        setupWallpaper();
        new Thread(() -> {
            for (File file : Utilities.getFileProviderDirectory(this).listFiles()) {
                if (!file.delete()) Log.w(TAG, "Could not remove an external file");
            }
            if (getIntent().getBooleanExtra("open_camera", false) &&
                    savedInstanceState == null) launchCamera(null);
        }).start();
    }

    private void setupToolbar() {
        final Toolbar toolbar = findViewById(R.id.chat_toolbar);
        toolbar.setTitle(getIntent().getStringExtra("name"));
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setIcon(R.drawable.ic_home_24dp);
        }
    }

    @SuppressWarnings("ClickableViewAccessibility")
    private void setupMessageList() {
        messageList = findViewById(R.id.chat_message_list);
        messageList.setLayoutManager(new LinearLayoutManager(this));
        messageList.setAdapter(new RecyclerView.Adapter<MessageViewHolder>() {
            @NonNull
            @Override
            public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new MessageViewHolder(LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_chat_message, parent, false));
            }

            @SuppressWarnings("SetTextI18n")
            @Override
            public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
                holder.layout.getViewTreeObserver().addOnGlobalLayoutListener(
                        new ViewTreeObserver.OnGlobalLayoutListener() {
                            @Override
                            public void onGlobalLayout() {
                                ViewGroup.MarginLayoutParams layoutParams =
                                        (ViewGroup.MarginLayoutParams)
                                                holder.layout.getLayoutParams();
                                layoutParams.leftMargin =
                                        -holder.hiddenInfoHolder.getMeasuredWidth();
                                holder.layout.setLayoutParams(layoutParams);
                                holder.layout.getViewTreeObserver()
                                        .removeOnGlobalLayoutListener(this);
                            }
                        });
                ViewGroup.MarginLayoutParams params =
                        (ViewGroup.MarginLayoutParams) holder.layout.getLayoutParams();
                switch (position) {
                    case 0:
                        holder.messageTime.setText("8:45 AM");
                        holder.messageSender.setText("Gregory Conrad");
                        holder.messageWrapper.setCardBackgroundColor(0xFF00FF00);
                        holder.messageText.setText("Hello World! How are you doing today?");
                        break;
                    case 1:
                        holder.messageTime.setText("8:45 AM");
                        params.topMargin = 0;
                        holder.messageWrapper.setCardBackgroundColor(0xFF00FF00);
                        holder.messageText.setText("Hello World! How are you doing today?\nHi\nHello");
                        holder.messageSender.setText("Gregory Conrad");
                        holder.picture.setImageResource(R.drawable.ic_emoji_24dp);
                        holder.picture.setCircleBackgroundColor(0x88FFFFFF);
                        break;
                    case 2:
                        holder.messageTime.setText("8:45 AM");
                        holder.messageWrapper.setCardBackgroundColor(0xFF0000FF);
                        holder.messageText.setText("Doing great, thanks for asking!");
                        holder.messageSender.setText("Ben Allen");
                        break;
                    case 3:
                        holder.messageTime.setText("8:46 AM");
                        params.topMargin = 0;
                        holder.messageWrapper.setCardBackgroundColor(0xFF0000FF);
                        holder.messageText.setText("How are you doing today?");
                        holder.messageSender.setText("Ben Allen");
                        holder.picture.setImageResource(R.drawable.ic_emoji_24dp);
                        holder.picture.setCircleBackgroundColor(0x88FFFFFF);
                        break;
                    case 4:
                        holder.messageTime.setText("8:46 AM");
                        holder.messageWrapper.setCardBackgroundColor(0xFF00FF00);
                        holder.messageSender.setText("Gregory Conrad");
                        holder.messageText.setText("Great.");
                        holder.picture.setCircleBackgroundColor(0x88FFFFFF);
                        break;
                    case 5:
                        holder.messageTime.setText("8:47 AM");
                        params.topMargin = 0;
                        holder.messageWrapper.setCardBackgroundColor(0xFF00FF00);
                        holder.messageSender.setText("Gregory Conrad");
                        holder.messageText.setText("See you later.");
                        holder.picture.setImageResource(R.drawable.ic_emoji_24dp);
                        holder.picture.setCircleBackgroundColor(0x88FFFFFF);
                        break;
                }
            }

            @Override
            public int getItemCount() {
                return 6;
            }
        });
        //todo load messages from Room -> getIntent().getStringExtra("id"););
        SlideDetector.OnSlideListener slideListener = new SlideDetector.OnSlideListener() {
            @Override
            public void onDown(SlideDetector detector) {
            }

            @Override
            public void onSlide(SlideDetector detector, float slideX, float slideY) {
                if (Math.abs(messageList.getX()) > getResources() // Limit extended movement
                        .getDimension(R.dimen.size_chat_message_list_slide_amount)) slideX /= 4;
                messageList.setX(messageList.getX() + slideX);
            }

            @Override
            public void onRelease(SlideDetector detector, boolean didSlide) {
                messageList.animate().translationX(0).setDuration(100);
            }
        };
        messageList.setOnTouchListener(new SlideDetector(
                SlideDetector.SlideMode.HORIZONTAL, slideListener));
    }

    private void setupAttachmentPreview() {
        composer = findViewById(R.id.chat_message_composer);
        composer.addOnLayoutChangeListener((v, left, top, right, bottom,
                                            oldLeft, oldTop, oldRight, oldBottom) -> {
            if (v.getHeight() != oldBottom - oldTop) messageList
                    .setPadding(0, 0, 0, v.getHeight() + getResources()
                            .getDimensionPixelSize(R.dimen.padding_chat_message_list_bottom));
        });
        attachmentPreview = findViewById(R.id.chat_attachment_preview);
        attachmentPreview.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        attachmentPreviewHeight = attachmentPreview.getHeight();
                        attachmentPreview.setVisibility(View.GONE);
                        attachmentPreview.getViewTreeObserver()
                                .removeOnGlobalLayoutListener(this);
                    }
                });
        findViewById(R.id.chat_attachment_delete_button)
                .setOnClickListener(v -> viewModel.removeAttachment());
        viewModel.displayAttachmentThumbnail.observe(this, ((ImageView)
                findViewById(R.id.chat_attachment_thumbnail))::setImageBitmap);
        viewModel.displayAttachmentFilename.observe(this, ((TextView)
                findViewById(R.id.chat_attachment_filename))::setText);
        viewModel.isFileAttached.observe(this, this::animateAttachmentPreview);
    }

    private void setupAttachmentPicker() {
        attachmentButton = findViewById(R.id.chat_attachment_button);
        attachmentButton.setOnLongClickListener(v -> {
            launchCamera(null);
            return true;
        });
        attachmentPicker = findViewById(R.id.chat_attachment_picker);
        attachmentPicker.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        attachmentPicker.animate().translationY(attachmentPicker.getHeight())
                                .setDuration(0).setListener(new AnimatorListenerAdapter() {
                            @Override
                            public void onAnimationEnd(Animator animation) {
                                super.onAnimationEnd(animation);
                                attachmentPicker.setVisibility(View.GONE);
                            }
                        });
                        attachmentPicker.getViewTreeObserver()
                                .removeOnGlobalLayoutListener(this);
                    }
                });
    }

    private void setupMessageText() {
        messageText = findViewById(R.id.chat_message_text);
        messageText.setOnRichContentListener((uri, description) -> {
            if (description.getMimeTypeCount() > 0) {
                final String extension = MimeTypeMap.getSingleton()
                        .getExtensionFromMimeType(description.getMimeType(0));
                viewModel.addAttachment(uri, "image." + extension, true);
            }
        });
    }

    private void setupWallpaper() {
        ImageView wallpaper = findViewById(R.id.chat_wallpaper);
        File file = new File(this.getFilesDir(), "wallpaper");
        Bitmap bitmap = file.exists() ? BitmapFactory.decodeFile(file.getAbsolutePath()) :
                BitmapFactory.decodeStream(getResources().openRawResource(R.raw.wallpaper_default));
        wallpaper.setImageBitmap(bitmap);
    }

    public void sendMessage(View view) {
        if (Utilities.isServiceRunning(this)) {
            assert viewModel.isFileAttached.getValue() != null;
            if (messageText.getText().toString().replaceAll(" ", "")
                    .replaceAll("\n", "").length() > 0 ||
                    viewModel.isFileAttached.getValue()) {
                viewModel.sendMessage(messageText.getText().toString());
                messageText.setText("");
            }
        } else {
            Utilities.showToast(this, R.string.chat_send_message_failure);
            Log.w(TAG, "User tried to send message while disconnected");
        }
    }

    /**
     * Called when the attachment thumbnail is clicked
     *
     * @param view The view that fired this method
     */
    public void openAttachment(View view) {
        new Thread(() -> {
            final File attachment = new File(Utilities.getFileProviderDirectory(this),
                    "attachment_" + Long.toString(System.currentTimeMillis()));
            if (!Utilities.writeToFileFromContentUri(this, attachment,
                    Uri.fromFile(viewModel.getAttachmentFile())))
                Log.e(TAG, "Could not copy the attachment into the fileprovider directory");
            final Uri uri = FileProvider.getUriForFile(this,
                    "cc.ticktalk.fileprovider", attachment);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            final int index = viewModel.attachmentFilename.lastIndexOf('.');
            if (index >= viewModel.attachmentFilename.length() - 1) return;
            String mimeType = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(viewModel.attachmentFilename.substring(index + 1));
            intent.setDataAndType(uri, mimeType);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            if (intent.resolveActivity(getPackageManager()) != null)
                startActivity(Intent.createChooser(intent,
                        getResources().getString(R.string.app_chooser_open_with)));
            else Utilities.showToast(this, R.string.chat_attach_failure_missing_app);
        }).start();
    }

    public void animateAttachmentPicker(View view) {
        animateAttachmentPicker(attachmentPicker.getVisibility() == View.GONE);
    }

    private void animateAttachmentPicker(boolean isOpening) {
        attachmentButton.animate().scaleX(0.2f).scaleY(0.2f).rotation(22.5f)
                .setDuration(100).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                attachmentButton.animate().scaleX(1.0f).scaleY(1.0f).setListener(null)
                        .rotation(isOpening ? 45.0f : 0.0f).setDuration(100);
            }
        });
        attachmentPicker.setVisibility(View.VISIBLE);
        attachmentPicker.animate().alpha(isOpening ? 1.0f : 0.0f)
                .translationY(isOpening ? 0.0f : attachmentPicker.getHeight())
                .setDuration(150).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                if (!isOpening) attachmentPicker.setVisibility(View.GONE);
            }
        });
    }

    private void animateAttachmentPreview(boolean isOpening) {
        if (isOpening) {
            ValueAnimator anim = ValueAnimator.ofInt(composer.getHeight(),
                    composer.getHeight() + attachmentPreviewHeight);
            anim.addUpdateListener(valueAnimator -> {
                ViewGroup.LayoutParams layoutParams = composer.getLayoutParams();
                layoutParams.height = (Integer) valueAnimator.getAnimatedValue();
                composer.setLayoutParams(layoutParams);
            });
            anim.addListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    attachmentPreview.setVisibility(View.VISIBLE);
                    ViewGroup.LayoutParams layoutParams = composer.getLayoutParams();
                    layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                    composer.setLayoutParams(layoutParams);
                    attachmentPreview.animate().alpha(1.0f).setDuration(150).setListener(null);
                }
            });
            anim.setDuration(175).start();
        } else {
            if (attachmentPreview.getVisibility() != View.VISIBLE) return;
            attachmentPreview.animate().alpha(0.0f)
                    .setDuration(150).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    ValueAnimator anim = ValueAnimator.ofInt(composer.getHeight(),
                            composer.getHeight() - attachmentPreviewHeight);
                    anim.addUpdateListener(valueAnimator -> {
                        ViewGroup.LayoutParams layoutParams = composer.getLayoutParams();
                        layoutParams.height = (Integer) valueAnimator.getAnimatedValue();
                        composer.setLayoutParams(layoutParams);
                    });
                    anim.addListener(new AnimatorListenerAdapter() {
                        @Override
                        public void onAnimationEnd(Animator animation) {
                            attachmentPreview.setVisibility(View.GONE);
                            ViewGroup.LayoutParams layoutParams = composer.getLayoutParams();
                            layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT;
                            composer.setLayoutParams(layoutParams);
                        }
                    });
                    anim.setDuration(175).start();
                }
            });
        }
    }

    public void launchForResult(Intent intent, int requestCode) {
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, requestCode);
            animateAttachmentPicker(false);
        } else Utilities.showToast(this, R.string.chat_attach_failure_missing_app);
    }

    public void launchCamera(View view) {
        try {
            final File fileProviderPath = Utilities.getFileProviderDirectory(this);
            final File imageFile = new File(fileProviderPath, "image.jpg");
            if (imageFile.exists() && !imageFile.delete())
                Log.w(TAG, "Could not delete the file");
            final Uri uri = FileProvider.getUriForFile(this,
                    "cc.ticktalk.fileprovider", imageFile);
            launchForResult(new Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                    .putExtra(MediaStore.EXTRA_OUTPUT, uri), CAMERA_REQUEST);
        } catch (Exception e) {
            Log.e(TAG, "Could not open the camera: " + e.getMessage());
            Utilities.showToast(this, R.string.chat_attach_failure_camera);
        }
    }

    public void launchPicturePicker(View view) {
        launchForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("image/*"), PICTURE_REQUEST);
    }

    public void launchFilePicker(View view) {
        launchForResult(new Intent(Intent.ACTION_GET_CONTENT).setType("*/*"), FILE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != RESULT_OK) {
            Log.w(TAG, "Could not attach the requested file: result not OK");
            return;
        }
        new Thread(() -> {
            switch (requestCode) {
                case CAMERA_REQUEST:
                    final File fileProviderPath = Utilities.getFileProviderDirectory(this);
                    viewModel.addAttachment(FileProvider.getUriForFile(this,
                            "cc.ticktalk.fileprovider",
                            new File(fileProviderPath, "image.jpg")), true);
                    break;
                case PICTURE_REQUEST:
                    viewModel.addAttachment(data.getData(), true);
                    break;
                case FILE_REQUEST:
                    viewModel.addAttachment(data.getData(), false);
                    break;
                default:
                    Log.e(TAG, "Unhandled request code");
            }
        }).start();
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
