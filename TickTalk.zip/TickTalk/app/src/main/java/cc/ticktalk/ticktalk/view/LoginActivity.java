package cc.ticktalk.ticktalk.view;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

import cc.ticktalk.ticktalk.R;
import cc.ticktalk.ticktalk.model.event_types.LoginFailure;
import cc.ticktalk.ticktalk.model.event_types.LoginSuccess;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        findViewById(R.id.login_button).setOnClickListener(v ->
                startActivity(new Intent(this, MainActivity.class)));
        startActivity(new Intent(this, MainActivity.class)); // todo remove
        EventBus.getDefault().register(this);
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe
    public void onLoginSuccess(LoginSuccess loginSuccess) {
        startActivity(new Intent(this, MainActivity.class));
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe
    public void onLoginFailure(LoginFailure loginFailure) {
        // todo
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }
}
