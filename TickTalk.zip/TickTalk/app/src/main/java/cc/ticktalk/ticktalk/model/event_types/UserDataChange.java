package cc.ticktalk.ticktalk.model.event_types;

import cc.ticktalk.ticktalk.model.protocol.types.UserData;

public class UserDataChange {
    public UserData newUserData;
    public UserDataChange(UserData userData) {
        this.newUserData = userData;
    }
}
