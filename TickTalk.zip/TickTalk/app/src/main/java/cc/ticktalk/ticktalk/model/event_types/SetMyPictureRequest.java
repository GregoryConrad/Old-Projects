package cc.ticktalk.ticktalk.model.event_types;

public class SetMyPictureRequest {
    public String picBase64;
    public SetMyPictureRequest(String picBase64) {
        this.picBase64 = picBase64;
    }
}
