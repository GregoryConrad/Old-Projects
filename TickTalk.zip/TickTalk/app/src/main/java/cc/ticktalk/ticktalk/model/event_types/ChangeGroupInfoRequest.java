package cc.ticktalk.ticktalk.model.event_types;

import cc.ticktalk.ticktalk.model.protocol.types.ChangeGroupInfo;

public class ChangeGroupInfoRequest {
    public ChangeGroupInfo request;
    public ChangeGroupInfoRequest(ChangeGroupInfo request) {
        this.request = request;
    }
}
