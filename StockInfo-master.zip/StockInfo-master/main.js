const {app, BrowserWindow} = require("electron");
app.on("ready",function(){
  let win = new BrowserWindow({width:300,height:100});
  win.loadURL("file://" + __dirname + "/index.html");
});
