/*
    Copyright (C) 2016 ETCG

    This file is part of PassGenv6.

    PassGenv6 is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    PassGenv6 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with PassGenv6.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "aboutwindow.h"
#include "successdialog.h"
#include "errorwindow.h"
#include <QApplication>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    worker = new Worker;
    this->setWindowTitle("PassGen v6");
    ui->lineEdit->setText("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789");
    ui->spinBox->setRange(1,30);
    ui->progressBar->setValue(0);
    ui->lineEdit_2->setText("Example: \"/Users/ME/Documents/passwords.txt\" (Windows Users: replace \\ with /)");
    ui->lineEdit_3->setReadOnly(true);
    ui->lineEdit_3->setText("Progress: 0%");
    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(close()));
    connect(worker,SIGNAL(workDone()),this,SLOT(PassGenDone()));
    connect(worker,SIGNAL(pBarChange(int)),this,SLOT(changePBar(int)));
    connect(worker,SIGNAL(errorOccured(QString)),this,SLOT(displayError(QString)));
    connect(worker,SIGNAL(success(int)),this,SLOT(displaySuccess(int)));
}

MainWindow::~MainWindow()
{
    delete ui;
    delete worker;
}

void MainWindow::on_pushButton_3_clicked()
{
    //When About button clicked:
    AboutWindow aboutwin;
    aboutwin.exec();
}

void MainWindow::on_pushButton_2_clicked()
{   //When Start button clicked:
    //Change the third button:
    disconnect(ui->pushButton,SIGNAL(clicked()),this,SLOT(close()));
    connect(ui->pushButton,SIGNAL(clicked()),worker,SLOT(changeCanceled()));
    ui->pushButton->setText("Stop");
    //Setup other things:
    this->setWindowTitle("Working...");

    //Get the thread up and running:
    worker->setValues(ui->lineEdit->text(),ui->lineEdit_2->text(),ui->spinBox->value()); //chars, file, len, this
    worker->start();
}

void MainWindow::changePBar(int a) {
    ui->progressBar->setValue(a);
    ui->lineEdit_3->setText(QStringLiteral("Progress: %1%").arg(a));
}

void MainWindow::PassGenDone() {
    //Changing back things to the way they were:
    //Change third button
    connect(ui->pushButton,SIGNAL(clicked()),this,SLOT(close()));
    ui->pushButton->setText("Close");
    disconnect(ui->pushButton,SIGNAL(clicked()),worker,SLOT(changeCanceled()));
    //Other things:
    this->setWindowTitle("PassGen v6");
    ui->lineEdit_3->setText("Progress: 0%");
    ui->progressBar->setValue(0);
    //Refresh Window:
    QApplication::processEvents();
    ui->pushButton->repaint();
}

void MainWindow::displayError(QString error) {
    ErrorWindow errorwindow;
    errorwindow.setError(error);
    errorwindow.exec();
}

void MainWindow::displaySuccess(int timeTaken) {
    //Open up successDialog:
    successDialog dia;
    dia.setTime(timeTaken);
    dia.exec();
}
