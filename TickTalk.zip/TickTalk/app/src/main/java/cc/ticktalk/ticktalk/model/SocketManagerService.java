package cc.ticktalk.ticktalk.model;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.IBinder;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.net.URISyntaxException;

import cc.ticktalk.ticktalk.model.event_types.*;
import cc.ticktalk.ticktalk.model.protocol.Requests;
import cc.ticktalk.ticktalk.model.protocol.types.*;

public class SocketManagerService extends Service {
    // todo Room should tell view/view model about updates and that stuff should be refreshed
    // todo utilize cache for some stuff
    // todo paging library https://codelabs.developers.google.com/codelabs/android-paging/index.html#0
    // https://codelabs.developers.google.com/codelabs/android-room-with-a-view/#0

    private static final String TAG = "SocketManagerService";
    private WebSocketClient socket;
    private Requests requests;
    private boolean isRestarting = false;
    private boolean isLoggedIn = false;
    private UserData myUserData;

    public SocketManagerService() {
        Log.d(TAG, "constructor called");
        requests = new Requests((requestID, name, data) -> {
            try {
                switch (name) {
                    case "displayServerMessage":
                        Toast.makeText(SocketManagerService.this, data,
                                Toast.LENGTH_LONG).show();
                        break;
                    case "updateUserData":
                        setMyUserData(data);
                        break;
                    case "showGroupMessage":
                        //GroupMessage groupMessage = new Gson().fromJson(data, GroupMessage.class);
                        // todo write db
                        break;
                    default:
                        Log.w(TAG, "Received unknown name from the server: " + name);
                }
            } catch (JsonSyntaxException e) {
                Log.w(TAG, "Received invalid json from the server: " + data);
            }
        }, new Requests.OnResultCallback() {
            @Override
            public void onReturn(String name, String data) {
                Log.w(TAG, "Received unknown return with name " + name + " and data " + data);
            }

            @Override
            public void onError(String name, String error) {
                Log.e(TAG, "Received unknown error with name " + name + " and error " + error);
            }
        });
    }

    @Override
    public void onCreate() {
        LocalBroadcastManager.getInstance(this).registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                LocalBroadcastManager.getInstance(SocketManagerService.this)
                        .sendBroadcastSync(new Intent("pong"));
            }
        }, new IntentFilter("ping"));
        EventBus.getDefault().register(this);
    }

    // Connects to the server and logs in when connected
    @Override
    public int onStartCommand(final Intent intent, int flags, final int startId) {
        Log.d(TAG, "onStartCommand called");
        closeSocket();
        myUserData = null;
        isLoggedIn = false;
        URI uri;
        try {
            uri = new URI("wss://chat.ticktalk.cc:6789");
        } catch (URISyntaxException e) {
            Log.wtf(TAG, "Invalid Server URL");
            EventBus.getDefault().post(new LoginFailure("Invalid server"));
            stopSelf(startId);
            return START_REDELIVER_INTENT;
        }
        socket = new WebSocketClient(uri) {
            @Override
            public void onOpen(ServerHandshake handshake) {
                socket.send(requests.generateRequest("login",
                        new Gson().toJson(new LoginObject(intent.getStringExtra("username"),
                                "", new String[][]{}, new String[][]{})), // fixme
                        new Requests.OnResultCallback() {
                            @Override
                            public void onReturn(String name, String data) {
                                isLoggedIn = true;
                                EventBus.getDefault().post(new LoginSuccess());
                                setMyUserData(data);
                            }

                            @Override
                            public void onError(String name, String error) {
                                EventBus.getDefault().post(new LoginFailure(error));
                                stopSelf(startId);
                            }
                        }));
            }

            @Override
            public void onMessage(String message) {
                requests.parseData(message);
            }

            @Override
            public void onClose(int code, String reason, boolean remote) {
                Log.e(TAG, "The " + (remote ? "server" : "client") + " closed the connection");
                Log.e(TAG, "Reason for connection close: " + reason);
                if (isLoggedIn) {
                    Toast.makeText(SocketManagerService.this,
                            "Connection lost: " + reason, Toast.LENGTH_LONG).show();
                    isRestarting = true;
                } else EventBus.getDefault().post(new LoginFailure(reason));
                stopSelf(startId);
            }

            @Override
            public void onError(Exception ex) {
                Log.e(TAG, "Socket encountered an error: " + ex.getMessage());
            }
        };
        socket.connect();
        return START_REDELIVER_INTENT;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void closeSocket() {
        if (socket != null) {
            Log.d(TAG, "Closing the socket");
            try {
                socket.closeBlocking();
            } catch (InterruptedException ie) {
                Log.w(TAG, "May not have properly closed the WebSocket's connection");
            }
        }
    }

    @Override
    public void onDestroy() {
        Log.d(TAG, "onDestroy called");
        EventBus.getDefault().unregister(this);
        closeSocket();
        if (isRestarting) startService(new Intent(this, SocketManagerService.class));
    }

    private void setMyUserData(String data) {
        myUserData = new Gson().fromJson(data, UserData.class);
        EventBus.getDefault().post(new UserDataChange(myUserData));
    }

    private void genericSend(String name, String data, Requests.OnResultCallback callback) {
        socket.send(requests.generateRequest(name, data, callback));
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onUserDataRequest(UserDataRequest request) {
        genericSend("getUserData", request.username, request.callback);
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onSetMyPictureRequest(SetMyPictureRequest request) {
        genericSend("setMyPicture", request.picBase64, new Requests.OnResultCallback() {
            @Override
            public void onReturn(String name, String data) {
                setMyUserData(data);
            }

            @Override
            public void onError(String name, String error) {
                Log.e(TAG, "Failed to set the signed in user's picture: " + error);
                Toast.makeText(SocketManagerService.this,
                        "Failed to set the picture: " + error, Toast.LENGTH_LONG).show();
            }
        });
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onSetMyDisplayNameRequest(SetMyDisplayNameRequest request) {
        genericSend("setMyDisplayName", request.displayName, new Requests.OnResultCallback() {
            @Override
            public void onReturn(String name, String data) {
                setMyUserData(data);
            }

            @Override
            public void onError(String name, String error) {
                Log.e(TAG, "Failed to set the signed in user's display name: " + error);
                Toast.makeText(SocketManagerService.this,
                        "Failed to set the display name: " + error,
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onMakeGroupRequest(MakeGroupRequest request) {
        genericSend("makeGroup", new Gson().toJson(request.request),
                new Requests.OnResultCallback() {
                    @Override
                    public void onReturn(String name, String data) {
                        setMyUserData(data);
                    }

                    @Override
                    public void onError(String name, String error) {
                        Log.e(TAG, "Failed to create a chat: " + error);
                        Toast.makeText(SocketManagerService.this,
                                "Failed to create the chat: " + error, Toast.LENGTH_LONG).show();
                    }
                });
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onChangeGroupInfoRequest(ChangeGroupInfoRequest request) {
        genericSend("changeGroupInfo", new Gson().toJson(request.request),
                new Requests.OnResultCallback() {
                    @Override
                    public void onReturn(String name, String data) {
                        setMyUserData(data);
                    }

                    @Override
                    public void onError(String name, String error) {
                        Log.e(TAG, "Failed to change group info: " + error);
                        Toast.makeText(SocketManagerService.this,
                                "Failed to change the info: " + error, Toast.LENGTH_LONG).show();
                    }
                });
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onChangeGroupUserRequest(ChangeGroupUserRequest request) {
        genericSend("changeGroupUser", new Gson().toJson(request.request),
                new Requests.OnResultCallback() {
                    @Override
                    public void onReturn(String name, String data) {
                        setMyUserData(data);
                    }

                    @Override
                    public void onError(String name, String error) {
                        Log.e(TAG, "Failed to change a group user: " + error);
                        Toast.makeText(SocketManagerService.this,
                                "Failed to fulfill your request", Toast.LENGTH_LONG).show();
                    }
                });
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onSendGroupMessageRequest(SendGroupMessageRequest request) {
        genericSend("sendGroupMessage", new Gson().toJson(request.message), null);
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onGroupMessageBlockRequest(GroupMessageBlockRequest request) {
        genericSend("getGroupMessageBlock", new Gson().toJson(request.request), null);
    }
}
