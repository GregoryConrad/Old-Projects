package cc.ticktalk.ticktalk.model.event_types;

import cc.ticktalk.ticktalk.model.protocol.types.ChangeGroupUser;

public class ChangeGroupUserRequest {
    public ChangeGroupUser request;
    public ChangeGroupUserRequest(ChangeGroupUser request) {
        this.request = request;
    }
}
