//Include Guard:
#ifndef __INCLUDES_H_INCLUDED__
#define __INCLUDES_H_INCLUDED__
#endif

//Includes:
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
#include <unistd.h>
#include <cstdlib>