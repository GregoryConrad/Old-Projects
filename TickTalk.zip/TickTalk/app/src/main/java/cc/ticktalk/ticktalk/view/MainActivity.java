package cc.ticktalk.ticktalk.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Bundle;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.SearchView;

import java.util.ArrayList;
import java.util.Stack;

import cc.ticktalk.ticktalk.R;
import cc.ticktalk.ticktalk.view.fragments.*;

// https://github.com/Zlate87/android-fingerprint-example
// https://developer.android.com/reference/android/accounts/AccountManager
// https://github.com/googlesamples/android-BasicSyncAdapter/#readme
// https://developer.android.com/guide/topics/data/data-storage
// https://github.com/googlesamples/android-architecture-components

public class MainActivity extends AppCompatActivity {
    private BottomNavigationView bottomNavigationView;
    private ConfigurableViewPager pager;
    private SearchView searchBar;
    private Stack<Integer> usedFrags = new Stack<>();
    private boolean isPoppingFrag = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setSupportActionBar(findViewById(R.id.main_toolbar));
        searchBar = findViewById(R.id.main_search);
        searchBar.getViewTreeObserver().addOnGlobalLayoutListener(
                new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        searchBar.animate().translationY(-searchBar.getHeight())
                                .setDuration(0).setListener(new AnimatorListenerAdapter() {
                            @Override
                            public void onAnimationEnd(Animator animation) {
                                super.onAnimationEnd(animation);
                                searchBar.setVisibility(View.GONE);
                            }
                        });
                        searchBar.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                    }
                });
        searchBar.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                // todo
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                // todo
                return true;
            }
        });
        pager = findViewById(R.id.main_viewpager);
        pager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                if (isPoppingFrag) isPoppingFrag = false;
                else usedFrags.push(position);
                switch (position) {
                    case 0:
                        bottomNavigationView.setSelectedItemId(R.id.navigation_home);
                        break;
                    case 1:
                        bottomNavigationView.setSelectedItemId(R.id.navigation_stories);
                        break;
                    case 2:
                        bottomNavigationView.setSelectedItemId(R.id.navigation_search);
                        animateSearchBar(true);
                        break;
                    case 3:
                        bottomNavigationView.setSelectedItemId(R.id.navigation_settings);
                        break;
                }
                if (position != 2 && searchBar.getVisibility() == View.VISIBLE)
                    animateSearchBar(false);
            }

            @Override
            public void onPageScrolled(int position, float positionOffset,
                                       int positionOffsetPixels) {
            }

            @Override
            public void onPageScrollStateChanged(int state) {
            }
        });
        pager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                switch (position) {
                    case 0:
                        return new HomeFragment();
                    case 1:
                        return new StoriesFragment();
                    case 2:
                        return new SearchFragment();
                    case 3:
                        return new SettingsFragment();
                }
                return null;
            }

            @Override
            public int getCount() {
                return 4;
            }
        });
        bottomNavigationView = findViewById(R.id.main_navigation);
        bottomNavigationView.setOnNavigationItemSelectedListener((MenuItem item) -> {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    pager.setCurrentItem(0, true);
                    return true;
                case R.id.navigation_stories:
                    pager.setCurrentItem(1, true);
                    return true;
                case R.id.navigation_search:
                    pager.setCurrentItem(2, true);
                    return true;
                case R.id.navigation_settings:
                    pager.setCurrentItem(3, true);
                    return true;
            }
            return false;
        });
        if (savedInstanceState == null) usedFrags.push(pager.getCurrentItem());
        else usedFrags.addAll(savedInstanceState.getIntegerArrayList("usedFrags"));
    }

    private void animateSearchBar(boolean isOpening) {
        searchBar.setVisibility(View.VISIBLE);
        searchBar.animate().alpha(isOpening ? 1.0f : 0.0f)
                .translationY(isOpening ? 0 : -searchBar.getHeight())
                .setDuration(150).setListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                if (!isOpening) searchBar.setVisibility(View.GONE);
            }
        });
    }

    @Override
    public void onBackPressed() {
        while (!usedFrags.empty() && usedFrags.peek() == pager.getCurrentItem()) usedFrags.pop();
        if (usedFrags.empty()) super.onBackPressed();
        else {
            isPoppingFrag = true;
            pager.setCurrentItem(usedFrags.pop(), true);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putIntegerArrayList("usedFrags", new ArrayList<>(usedFrags));
        super.onSaveInstanceState(outState);
    }
}
