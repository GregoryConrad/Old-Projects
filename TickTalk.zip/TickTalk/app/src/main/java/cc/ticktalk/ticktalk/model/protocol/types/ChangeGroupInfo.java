package cc.ticktalk.ticktalk.model.protocol.types;

public class ChangeGroupInfo {
    String groupID;
    String whatToChange;
    String data;
}
