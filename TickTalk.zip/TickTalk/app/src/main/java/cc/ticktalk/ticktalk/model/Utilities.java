package cc.ticktalk.ticktalk.model;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;

public class Utilities {
    private static final String TAG = "Utilities";

    public static int stringToColor(String str) {
        int returnVal = 0xFF000000;
        try {
            byte[] nameDigest;
            nameDigest = MessageDigest.getInstance("MD5")
                    .digest(str.getBytes("UTF-8"));
            int currColor = 0xFF, color = 0; //currColor represents either r, g, or b
            for (int i = 0; i < nameDigest.length; ++i) {
                if (i % (nameDigest.length / 3) == 0) {
                    color <<= 8;
                    color += currColor & 0xFF;
                    currColor = 0;
                }
                currColor += nameDigest[i];
            }
            returnVal = color;
        } catch (Exception e) {
            Log.e(TAG, "stringToColor encountered an error: " + e.getMessage());
            e.printStackTrace();
        }
        return returnVal;
    }

    public static boolean writeToFileFromContentUri(Context context, File file, Uri uri) {
        if (context == null || file == null || uri == null) return false;
        try (InputStream stream = context.getContentResolver().openInputStream(uri);
             OutputStream output = new FileOutputStream(file)) {
            if (stream == null) return false;
            byte[] buffer = new byte[4 * 1024];
            int read;
            while ((read = stream.read(buffer)) != -1) output.write(buffer, 0, read);
            output.flush();
            return true;
        } catch (FileNotFoundException e) {
            Log.e(TAG, "Couldn't open stream: " + e.getMessage());
        } catch (IOException e) {
            Log.e(TAG, "IOException on stream: " + e.getMessage());
        }
        return false;
    }

    public static String getFilenameFromUri(Context context, Uri uri) {
        if (context == null || uri == null) return null;
        String returnVal = null;
        try (Cursor cursor = context.getContentResolver()
                .query(uri, null, null, null, null)) {
            if (cursor == null) throw new Exception("Cursor is null");
            cursor.moveToFirst();
            returnVal = cursor.getString(cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME));
        } catch (Exception e) {
            Log.e(TAG, "Could not get the filename: " + e.getMessage());
        }
        return returnVal;
    }

    public static boolean isServiceRunning(Context context) {
        final boolean[] isRunning = {false};
        LocalBroadcastManager.getInstance(context).registerReceiver(new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                isRunning[0] = true;
                LocalBroadcastManager.getInstance(context).unregisterReceiver(this);
            }
        }, new IntentFilter("pong"));
        LocalBroadcastManager.getInstance(context).sendBroadcastSync(new Intent("ping"));
        return isRunning[0];
    }

    public static void showToast(Context context, int resId) {
        new Handler(Looper.getMainLooper()).post(() ->
                Toast.makeText(context, resId, Toast.LENGTH_LONG).show());
    }

    public static File getFileProviderDirectory(Context context) {
        final File fileProviderPath = new File(context.getFilesDir(), "fileprovider");
        if (!fileProviderPath.exists() && !fileProviderPath.mkdir())
            Log.e(TAG, "Could not create the fileprovider directory");
        return fileProviderPath;
    }
}
