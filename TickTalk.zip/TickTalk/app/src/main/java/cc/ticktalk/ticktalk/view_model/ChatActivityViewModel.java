package cc.ticktalk.ticktalk.view_model;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MutableLiveData;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.util.Log;

import java.io.File;

import cc.ticktalk.ticktalk.R;
import cc.ticktalk.ticktalk.model.Utilities;

public class ChatActivityViewModel extends AndroidViewModel {
    private static final String TAG = "ChatActivityViewModel";
    public String attachmentFilename = null;
    public MutableLiveData<Bitmap> displayAttachmentThumbnail = new MutableLiveData<>();
    public MutableLiveData<String> displayAttachmentFilename = new MutableLiveData<>();
    public MutableLiveData<Boolean> isFileAttached = new MutableLiveData<>();

    // persistable viewmodel https://developer.android.com/studio/projects/android-library
    // make each activity have its own viewmodel from id
    //     also change attachment to attachment_id
    // https://medium.com/@kostasdrakonakis/how-to-distribute-your-own-android-library-through-jitpack-or-jcenter-and-maven-central-from-174c356e818a
    // https://dzone.com/articles/creating-custom-annotations-in-java
    // buy gsconrad.com first
    // DataBindingUtil for inflating layouts in frag/activity
    // https://developer.android.com/topic/libraries/data-binding/ if needed

    public ChatActivityViewModel(Application application) {
        super(application);
        isFileAttached.setValue(false);
    }

    /**
     * Adds an attachment
     * Precondition: File returned from getAttachmentFile() has been populated
     *
     * @param uri the uri of the file (probably from the content provider)
     * @param filename the filename (not simply "attachment", that is for internal use)
     * @param isPicture if the attachment is known to be a picture (for an error message)
     */
    public void addAttachment(Uri uri, String filename, boolean isPicture) {
        if (filename != null && Utilities.writeToFileFromContentUri(
                getApplication(), getAttachmentFile(), uri)) {
            attachmentFilename = filename;
            Bitmap thumbnail = BitmapFactory.decodeFile(getAttachmentFile().getAbsolutePath());
            if (thumbnail == null) {
                Drawable fileIcon = getApplication().getResources()
                        .getDrawable(R.drawable.ic_file_24dp);
                final int size = getApplication().getResources()
                        .getDimensionPixelSize(R.dimen.size_chat_attachment_thumbnail);
                Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
                bitmap.eraseColor(getApplication().getResources().getColor(R.color.colorAccent));
                Canvas canvas = new Canvas(bitmap);
                fileIcon.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
                fileIcon.draw(canvas);
                displayAttachmentThumbnail.postValue(bitmap);
                displayAttachmentFilename.postValue(attachmentFilename);
            } else {
                displayAttachmentThumbnail.postValue(thumbnail);
                displayAttachmentFilename.postValue("");
            }
            isFileAttached.postValue(true);
        } else Utilities.showToast(getApplication(), isPicture ?
                R.string.chat_attach_failure_picture : R.string.chat_attach_failure_file);
    }

    public void addAttachment(Uri uri, boolean isPicture) {
        addAttachment(uri, Utilities.getFilenameFromUri(getApplication(), uri), isPicture);
    }

    public File getAttachmentFile() {
        return new File(getApplication().getFilesDir(), "attachment");
    }

    public void removeAttachment() {
        isFileAttached.setValue(false);
        if (!getAttachmentFile().delete()) Log.w(TAG, "Could not remove the attachment file");
    }

    @SuppressWarnings("unused")
    public void sendMessage(String text) {
        attachmentFilename = "";
        // todo forward to service
        removeAttachment();
    }
}
