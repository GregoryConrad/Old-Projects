# cmdGen
A simple and powerful script that combines multiple minecraft commands into one single command.

Author: ETCG

Contact:
  - email : epictincangames@gmail.com
  - skype : flare.cat

Note: By using cmdGen (including its source), you agree that ETCG does not take any responisibility for any negative consequence that cmdGen causes. Use cmdGen at your own risk.

Operation:
When I say command line interface (CLI), I mean your Operating System's command processor. On Windows, this is Command Prompt; on Mac/Linux this is Terminal.
  1. Open your CLI.
  2. Drag the executable with your OS' name into the CLI window. (Windows: "Windows.exe"; Mac: "Mac"; Linux: I didn't make one; you can try the Mac one, and if it doesn't work you'll have to compile the code yourself ("g++ cmdGen*.cpp -o cmdGenLinux").)
  3. Hit the space bar.
  4. Drag the file with the input commands in. 
  (Steps 5 and 6 are optional, if you want the resulting command in a text file.)
  5. Hit the space bar.
  6. Drag in the output file.
  7. Hit ENTER/return.
  (If you choose to follow steps 5 and 6, your commmand will be in the output file. If not, continue.)
  8. Scroll to the point in which the command starts (it starts with "/summon").
  9. If you are using Windows, right click -> Mark.
  10. Select the entire command.
  11. If you are on Mac, hit Command + C. If you are using Windows/Linux, hit Ctrl + C. This will copy the command to your clipboard.

License:
The MIT License (MIT)

Copyright (c) 2016 ETCG

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
