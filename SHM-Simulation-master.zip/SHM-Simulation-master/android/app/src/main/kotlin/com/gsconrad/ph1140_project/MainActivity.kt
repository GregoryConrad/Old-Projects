package com.gsconrad.ph1140_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
