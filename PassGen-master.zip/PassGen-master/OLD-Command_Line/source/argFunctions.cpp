//Include:
#include "argFunctions.h"
//Functions:
void argFunctions::setValuesArg(char **a, int b) {
	for (int i = 0; i < b; i++) {
		args.push_back(a[i]);
	}
}
void argFunctions::setValuesVMode(bool a) {
	verboseMode = a;
}
bool argFunctions::checkParameter(std::string parameter) { //Checks to see if a parameter is present,								   //by searching the argument array.
	for (int i = 0; i < args.size(); i++)
	{
		if (args[i] == parameter) {
			return true;
		}
	}
	return false;
}
const char *argFunctions::getValue(std::string parameter) { //Gets a value for the given parameter.
	std::string temp;
	for (int i = 0; i < args.size(); i++)
	{
		if (args[i] == parameter) {
			if (i + 1 < args.size()) {
				temp = args[i + 1];
				args.erase(args.begin() + i + 1);
				args.erase(args.begin() + i);
				return temp.c_str();
			}
			else {
				return NULL; //Catches a bug, caused by returning an undefined part of the args vector.
			}
		}
	}
	return NULL; //Returns an error.
}
void argFunctions::removeValue(std::string parameter) {
	for (int i = 0; i < args.size(); i++) {
		if (args[i] == parameter) {
			args.erase(args.begin() + i);
			break;
		}
	}
}
int argFunctions::checkDir() {
	if (checkParameter("-d")) {
		const char *directory = getValue("-d");
		int correctDirectory = chdir(directory);
		if (correctDirectory != 0) {
			if (verboseMode) {
				std::cout << "Invalid directory. Use -h to see help/correct usage.\nTerminating...\n";
			}
			return -1; //Error code.
		}
	}
	return 0;
}