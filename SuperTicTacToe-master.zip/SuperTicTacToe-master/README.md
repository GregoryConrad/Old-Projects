#Super Tic Tac Toe
A Classic Tic Tac Toe Game, With A Twist!

***Modes:***

**There are three modes:**
  - "single" -> Singleplayer
  - "multi"  -> Multiplayer
  - "help"   -> A help menu

**Singleplayer:**

A mode in which a player (called Player 1) plays against the computer (called Player 2). Look at the gameplay section to learn how to play.

**Multiplayer:**

A mode in which one player (called Player 1) plays against another player (called Player 2). This mode does not use internet, so both players must be together. The computer will prompt each player with coordinates, when it is their turn. Go to the gameplay section to learn how to play.

**Help:**

A simplified help menu. Please read on for more advanced help.



***Gameplay:***

This game is like a regular tic tac toe game, with 9 different sections (divided into a 3 by 3 grid). But, Super Tic Tac Toe has another tic tac toe game in each of these 9 sections. So, there are 9 different tic tac toe games brought together to make one.

Also, when playing, there will always be a winner of each mini tic tac toe game; whoever has more pieces in the mini tic tac toe game wins that specific section. But, the overall game can be a tie.

When a user is asked for coordinates, the user should type in the exact position of the spot they want to obtain. There are nine different rows and columns, so the first spot is `1 1` and the last spot is `9 9` (values start at one, and end at nine). Also, enter the coordinate with the row number first, and the column number last.

Please look up regular tic tac toe rules if you want to know how exactly the game works.

So, the board is divided into a 3x3 grid, with each of those 9 sections having another 3x3 grid.



***Contact Me:***

For any bugs, comments, or questions, email me at: epictincangames@gmail.com



***License:***

Please read the LICENSE file for the license. This application is under the MIT LICENSE.
