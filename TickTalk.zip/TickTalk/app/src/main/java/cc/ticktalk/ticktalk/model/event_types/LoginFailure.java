package cc.ticktalk.ticktalk.model.event_types;

public class LoginFailure {
    String reason;

    public LoginFailure(String reason) {
        this.reason = reason;
    }
}
