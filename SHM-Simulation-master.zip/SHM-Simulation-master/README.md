# SHM Simulation

My PH1140 Final Project, a simple harmonic motion (SHM) simulation and calculator created in [Flutter](https://flutter.dev). Includes a spring-mass system and a simple pendulum.

See https://gregoryconrad.github.io/SHM-Simulation
