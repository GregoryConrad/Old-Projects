/*
    Copyright (C) 2016 ETCG

    This file is part of PassGenv6.

    PassGenv6 is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    PassGenv6 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with PassGenv6.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "worker.h"
#include "mainwindow.h"
#include <QTime>
#include <QFile>
#include <QTextStream>

void Worker::run () {
    //Take time:
    QTime timer;
    timer.start();

    //The following line prevents a bug from happeneing. If a user stops PassGen mid-run, they can't run it again.
    canceled = false;

    //This is the meat of the program:
    bool temp = PassGen();
    emit workDone();
    if (temp) { //all went well
        emit success(timer.elapsed());
    }
    else {
        emit errorOccured(error);
    }
}

bool Worker::PassGen() {
    //Checks:
    bool okToGo = true;

    //Check to see if the number given is correct (in case the OS messed up):
    if (!(pLength > 0 && pLength < 31)) {
        okToGo = false;
        error = "Invalid password length.\nPlease report your OS to contact@etcg.pw.";
    }

    //No check needed for chars. (At least for now, maybe will later.)


    //Check for ability to open file:
    QFile file(filename);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text)) {
        okToGo = false;
        error = "Could not open file.";
    }

    //If anything failed:
    if (!okToGo) {
        //Quit:
        return false;
    }

    //Generate a loop variable:
    unsigned long long int loopmax = 1;
    for (int loopmaxgen = 0; loopmaxgen < pLength; loopmaxgen++) {
        loopmax *= chars.length();
    }
    //Create other variables:
    QString currentPassword;
    int numcomboadd;
    int numcombo[30] = {0};
    double currentUpdateVal = 0;

    //Make it so we can write to file:
    QTextStream passwords(&file);

    //Run the main loop:
    for(unsigned long long loopcounter = 0; loopcounter < loopmax; loopcounter++) {
        if (!canceled) {
            //Setup:
            currentPassword = "";

            //Password builder:
            for (int buildcounter = 0; buildcounter < pLength; buildcounter++) {
                currentPassword += chars[numcombo[buildcounter]];
            } //Takes numerical value from numcombo, and converts it into a password stored in passwords.txt.
            passwords << currentPassword << endl;

            //Password adder:
            for (numcomboadd = 0; numcombo[numcomboadd] == chars.length() - 1; numcomboadd++) {
                numcombo[numcomboadd] = 0; //deals with carry-over
            }
            numcombo[numcomboadd]++;

            //Update the progress bar, if needed:
            if (((double)loopcounter/(double)loopmax) >= currentUpdateVal) {
                emit pBarChange((int)(100*loopcounter/loopmax));
                currentUpdateVal += 0.01;
            }
        }
        else {
            break;
        }
    }
    return true;
}

void Worker::changeCanceled() {
    canceled = true;
}

void Worker::setValues(QString a, QString b, int c) { //chars, file, len
    chars   = a;
    filename     = b;
    pLength = c;
}
