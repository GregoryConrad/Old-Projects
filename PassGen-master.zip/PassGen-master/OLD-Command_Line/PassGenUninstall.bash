#!/bin/bash
#Uninstaller for PassGen
FILE="/usr/local/bin/PassGen"
if [ -x "$FILE" ]
then
	sudo rm "$FILE"
	echo "Uninstall successful."
	echo "I hope you enjoyed using PassGen."
else
	echo "PassGen is not installed, or is corrupted." 
	echo "If it is installed, please do a manual uninstall, by deleting /usr/local/bin/PassGen"
	exit 1
fi
exit