package cc.ticktalk.ticktalk.view_model;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

import java.util.ArrayList;
import java.util.HashMap;

import cc.ticktalk.ticktalk.model.event_types.UserDataChange;

public class HomeFragmentViewModel extends ViewModel {
    public class ChatDisplayable {
        public String name;
        public String pic;
        public String details; // todo make Person: Message
        public String time;

        ChatDisplayable(String name, String pic, String details, String time) {
            this.name = (name == null) ? "" : name;
            this.pic = (pic == null) ? "" : pic;
            this.details = (details == null) ? "" : details;
            this.time = (time == null) ? "" : time;
        }
    }

    public MutableLiveData<ChatDisplayable[]> chats = new MutableLiveData<>();

    public HomeFragmentViewModel() {
        // todo remove this in final version
        chats.setValue(new ChatDisplayable[]{
                new ChatDisplayable("Wurld Cup Hellp", "",
                        "Jonah: Some thang", "8:45 AM"),
                new ChatDisplayable("Some random group name that is also very very long",
                        "", "You: This chat not only has a long title. " +
                        "It also has an extremely long description that wraps multiple lines",
                        "12:34 AM"),
                new ChatDisplayable("Some random group name", "", "You: Ayy lmao",
                        "5:16 PM"),
                new ChatDisplayable("Alex Mingolla", "", "Alex: Dat dude",
                        "1:03 AM"),
                new ChatDisplayable("Nachi", "", "Nachi: Hi", "4:20 PM")
        });
        EventBus.getDefault().register(this);
    }

    @Override
    protected void onCleared() {
        EventBus.getDefault().unregister(this);
    }

    @SuppressWarnings({"UnusedDeclaration"})
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onUserDataChange(UserDataChange userDataChange) {
        ArrayList<ChatDisplayable> newGroups =
                new ArrayList<>(userDataChange.newUserData.groups.length);
        for (HashMap<String, String> group : userDataChange.newUserData.groups) {
            newGroups.add(new ChatDisplayable(group.get("name"),
                    group.get("pic"), group.get("description"), "fixme"));
            // todo change description to last msg
        }
        chats.postValue((ChatDisplayable[]) newGroups.toArray());
    }
}
