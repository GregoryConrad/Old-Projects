/*
    Copyright (C) 2016 ETCG

    This file is part of PassGenv6.

    PassGenv6 is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    PassGenv6 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with PassGenv6.  If not, see <http://www.gnu.org/licenses/>.
*/

#include "errorwindow.h"
#include "ui_errorwindow.h"

ErrorWindow::ErrorWindow(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::ErrorWindow)
{
    ui->setupUi(this);
    this->setWindowTitle("Error");
}

ErrorWindow::~ErrorWindow()
{
    delete ui;
}

void ErrorWindow::setError(QString a) {
    ui->label->setText(a);
}
