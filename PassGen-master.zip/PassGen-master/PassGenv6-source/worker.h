/*
    Copyright (C) 2016 ETCG

    This file is part of PassGenv6.

    PassGenv6 is free software: you can redistribute it and/or modify
    it under the terms of the GNU Lesser General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    PassGenv6 is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public License
    along with PassGenv6.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef WORKER_H
#define WORKER_H

#include <QThread>
#include <QMainWindow>
#include "errorwindow.h"

class Worker : public QThread
{
    Q_OBJECT
public:
    void setValues (QString, QString, int);
private:
    void run();
    bool PassGen(); //Generates the passwords, and runs a check
    QString chars; //Characters used to generate the file
    int pLength; //Stores the length of the password
    QString filename; //Stores the filename
    bool canceled;
    QString error;

signals:
    void workDone();
    void pBarChange(int);
    void errorOccured(QString);
    void success(int);

public slots:
    void changeCanceled();
};

#endif // WORKER_H
