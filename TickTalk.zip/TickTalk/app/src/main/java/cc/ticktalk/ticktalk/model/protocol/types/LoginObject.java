package cc.ticktalk.ticktalk.model.protocol.types;

public class LoginObject {
    public LoginObject(String username, String password,
                       String[][] lastSeenGroupMsgIDs, String[][] lastSeenRoomMsgIDs) {
        this.username = username;
        this.password = password;
        this.lastSeenGroupMsgIDs = lastSeenGroupMsgIDs;
        this.lastSeenRoomMsgIDs = lastSeenRoomMsgIDs;
    }

    private String username;
    private String password;
    int protocol = 6;
    private String[][] lastSeenGroupMsgIDs;
    private String[][] lastSeenRoomMsgIDs;
}
