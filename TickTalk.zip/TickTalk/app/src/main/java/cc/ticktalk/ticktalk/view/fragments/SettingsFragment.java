package cc.ticktalk.ticktalk.view.fragments;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.preference.PreferenceFragmentCompat;
import android.preference.PreferenceManager;
import android.util.Log;
import android.widget.Toast;

import java.io.File;

import cc.ticktalk.ticktalk.R;
import cc.ticktalk.ticktalk.model.Utilities;

public class SettingsFragment extends PreferenceFragmentCompat {
    private static final String TAG = "SettingsFragment";

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        if (getActivity() == null) Log.w(TAG, "Could not set the default preferences");
        else PreferenceManager.setDefaultValues(getActivity(), R.xml.preferences, false);
        setPreferencesFromResource(R.xml.preferences, null);
        findPreference("wallpaper").setOnPreferenceClickListener(preference -> {
            startActivityForResult(new Intent(Intent.ACTION_GET_CONTENT)
                    .setType("image/*"), 1);
            return true;
        });
        findPreference("remove_wallpaper").setOnPreferenceClickListener(preference -> {
            removeWallpaper();
            return true;
        });
    }

    private void removeWallpaper() {
        if (getContext() == null ||
                !new File(getContext().getFilesDir(), "wallpaper").delete()) {
            Log.e(TAG, "Failed to remove the wallpaper");
        }
    }

    @Override
    @SuppressWarnings("ConstantConditions")
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
            if (!Utilities.writeToFileFromContentUri(getContext(),
                    new File(getContext().getFilesDir(), "wallpaper"), data.getData())) {
                Toast.makeText(getContext(), "Could not change the wallpaper",
                        Toast.LENGTH_LONG).show();
                removeWallpaper();
            }
        }
    }
}