# StockInfo
A simple application that check's a stock's price. Built using electron and node.js


# Instructions
To run the application, run the following commands (in the directory that contains index.html, main.js, and package.json):

1. `npm install electron-prebuilt requests`
2. `npm start`

# Author
Created by: Gregory Conrad

# Website
Website: http://GregoryConrad.github.io

# License
This application's source is under the LGPL, version 3 (or any later version).
