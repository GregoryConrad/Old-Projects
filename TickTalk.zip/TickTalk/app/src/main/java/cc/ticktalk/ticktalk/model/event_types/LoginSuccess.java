package cc.ticktalk.ticktalk.model.event_types;

public class LoginSuccess {
}
