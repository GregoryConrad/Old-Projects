package cc.ticktalk.ticktalk.model.event_types;

import cc.ticktalk.ticktalk.model.protocol.types.GroupMessage;

public class SendGroupMessageRequest {
    public GroupMessage message;
    public SendGroupMessageRequest(GroupMessage message) {
        this.message = message;
    }
}
