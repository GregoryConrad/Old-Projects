package cc.ticktalk.ticktalk.model.event_types;

import cc.ticktalk.ticktalk.model.protocol.Requests;

public class UserDataRequest {
    public String username;
    public Requests.OnResultCallback callback;
    public UserDataRequest(String username, Requests.OnResultCallback callback) {
        this.username = username;
        this.callback = callback;
    }
}
