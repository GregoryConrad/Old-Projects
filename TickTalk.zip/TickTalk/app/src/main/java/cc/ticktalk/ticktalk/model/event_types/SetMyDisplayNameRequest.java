package cc.ticktalk.ticktalk.model.event_types;

public class SetMyDisplayNameRequest {
    public String displayName;
    public SetMyDisplayNameRequest(String displayName) {
        this.displayName = displayName;
    }
}
