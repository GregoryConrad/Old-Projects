package cc.ticktalk.ticktalk.view.fragments;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import com.daimajia.swipe.SwipeLayout;

import cc.ticktalk.ticktalk.R;
import cc.ticktalk.ticktalk.model.Utilities;
import cc.ticktalk.ticktalk.view.ChatActivity;
import cc.ticktalk.ticktalk.view_model.HomeFragmentViewModel;
import de.hdodenhof.circleimageview.CircleImageView;

public class HomeFragment extends Fragment {
    private static final String TAG = "HomeFragment";
    private RecyclerView recyclerView = null;
    private HomeFragmentViewModel viewModel = null;

    class ViewHolder extends RecyclerView.ViewHolder {
        SwipeLayout layout;
        ConstraintLayout wrapper;
        CircleImageView image;
        TextView title, details, time;
        ImageButton infoButton, muteButton, archiveButton, cameraButton;

        ViewHolder(View itemView) {
            super(itemView);
            layout = itemView.findViewById(R.id.home_chat_item_layout);
            wrapper = itemView.findViewById(R.id.home_chat_item_wrapper);
            image = itemView.findViewById(R.id.home_chat_item_image);
            title = itemView.findViewById(R.id.home_chat_item_title);
            details = itemView.findViewById(R.id.home_chat_item_details);
            time = itemView.findViewById(R.id.home_chat_item_time);
            infoButton = itemView.findViewById(R.id.home_chat_item_info);
            muteButton = itemView.findViewById(R.id.home_chat_item_mute);
            archiveButton = itemView.findViewById(R.id.home_chat_item_archive);
            cameraButton = itemView.findViewById(R.id.home_chat_item_camera);
        }
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);
        viewModel = ViewModelProviders.of(this).get(HomeFragmentViewModel.class);
        rootView.findViewById(R.id.fab).setOnClickListener(view -> // todo NewChatActivity
                Snackbar.make(view, "Here's a Snack bar", Snackbar.LENGTH_LONG).show());
        recyclerView = rootView.findViewById(R.id.chats_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(new RecyclerView.Adapter<ViewHolder>() {
            @NonNull
            @Override
            public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new ViewHolder(LayoutInflater.from(parent.getContext())
                        .inflate(R.layout.item_home_chatlist, parent, false));
            }

            @Override
            public void onBindViewHolder(@NonNull final ViewHolder holder, int position) {
                new Thread(() -> {
                    final Bitmap bitmap = getImage(holder.getAdapterPosition());
                    new Handler(Looper.getMainLooper()).post(() -> {
                        holder.image.setImageBitmap(bitmap);
                        holder.image.animate().alpha(1.0f).setDuration(100);
                    });
                }).start();
                holder.layout.setShowMode(SwipeLayout.ShowMode.LayDown);
                holder.title.setText(getTitle(position));
                holder.details.setText(getDetails(position));
                holder.time.setText(getLastMessageTime(position));
                holder.wrapper.setOnClickListener(v ->
                        startActivity(new Intent(getContext(), ChatActivity.class)
                                .putExtra("id", "") // fixme
                                .putExtra("name", holder.title.getText())));
                holder.wrapper.setOnLongClickListener(v -> {
                    startActivity(new Intent(getContext(), ChatActivity.class)
                            .putExtra("id", "") // fixme
                            .putExtra("name", holder.title.getText())
                            .putExtra("open_camera", true));
                    return true;
                });
                holder.cameraButton.setOnClickListener(v ->
                        startActivity(new Intent(getContext(), ChatActivity.class)
                                .putExtra("id", "") // fixme
                                .putExtra("name", holder.title.getText())
                                .putExtra("open_camera", true)));
            }

            private Bitmap getImage(int position) {
                Bitmap bitmap;
                String picBase64 = viewModel.chats.getValue()[position].pic;
                try {
                    if (picBase64.equals("")) throw new Exception("No picture provided");
                    byte[] bytes = Base64.decode(picBase64, Base64.DEFAULT);
                    bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    if (bitmap == null) throw new Exception("Could not decode the image");
                } catch (Exception e) {
                    Log.w(TAG, "Could not display a group image: " + e.getMessage());
                    bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
                    bitmap.eraseColor(Utilities.stringToColor(getTitle(position)));
                }
                return bitmap;
            }

            private String getTitle(int position) {
                return viewModel.chats.getValue()[position].name;
            }

            private String getDetails(int position) {
                return viewModel.chats.getValue()[position].details;
            }

            private String getLastMessageTime(int position) {
                return viewModel.chats.getValue()[position].time;
            }

            @Override
            public int getItemCount() {
                return viewModel.chats.getValue().length;
            }
        });
        viewModel.chats.observe(this, x -> recyclerView.getAdapter().notifyDataSetChanged());
        return rootView;
    }
}
