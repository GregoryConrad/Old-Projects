package cc.ticktalk.ticktalk.model.event_types;

import cc.ticktalk.ticktalk.model.protocol.types.MakeGroup;

public class MakeGroupRequest {
    public MakeGroup request;
    public MakeGroupRequest(MakeGroup request) {
        this.request = request;
    }
}
