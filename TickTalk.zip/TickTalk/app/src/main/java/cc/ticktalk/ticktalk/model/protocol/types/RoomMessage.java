package cc.ticktalk.ticktalk.model.protocol.types;

public class RoomMessage {
    String room;
    String id;
    String username;
    String timestamp;
    String replyTo;
    String msg;
    String file;
    String filename;
}
