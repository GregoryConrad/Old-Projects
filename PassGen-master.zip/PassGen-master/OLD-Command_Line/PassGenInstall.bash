#!/bin/bash
#Installer for PassGen

function displayError {
	echo "To install PassGen, run:"
	echo "sudo cp <location_of_passgen> /usr/local/bin"
	echo "Replace <location_of_passgen> with the location of PassGen. Example:"
	echo "~/Downloads/PassGen/exec/PassGen"
	echo "Terminating..."
	exit 1
}

DIR="exec"
if [ -d "$DIR" ]
then
	cd "$DIR"
else
	echo "PassGen's executable directory(PassGen/exec) was not found."
	displayError
fi

FILE="PassGen"
if [ -x "$FILE" ]
then
	sudo cp "$FILE" "/usr/local/bin"
	echo "Installation was successful."
	echo "You can now run PassGen by running \"PassGen\" from the command line."
	echo "Remember: Use for LEGAL PURPOSES ONLY!"
else
	echo "PassGen's executable file was not found."
	displayError
fi
exit