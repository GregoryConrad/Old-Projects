# PassGen
A dictionary file generator

#----Author----#
Original author: ETCG_FlareCat 
The original author is Epic Tin Can Games(ETCG) on youtube:
https://www.youtube.com/channel/UC5W7n0gefWSWXBqefZPrgLQ

#----Install---#
Do not modify any contents of the folder "PassGen" and any of its sub-directories before installing.
If you do, installation may not succeed, or PassGen may be corrupted.
In the command line, change your directory to the directory that contains "PassGenInstall.bash".
Then run the following: sudo bash PassGenInstall.bash
If building from source, the following command is how I built it: g++ *.cpp -o PassGen

#---Uninstall--#
In the command line, change your directory to the directory that contains "PassGenUninstall.bash".
Then run the following: sudo bash PassGenUninstall.bash

#---Operation--#
I suggest you do not run PassGen as root/super user/administrator(Non-standard privileges).
While PassGen is running, hit Control-C to abort at any time.
Options:
  -h, -help       : Shows this help menu
  -v              : Turns on verbose mode
  -npb            : Doesn't display progress bar
  -d <directory>  : Makes the password file in the given directory
  -pl <number>    : Sets the password length (has to be between 1 and 20)
  -c <characters> : Sets the characters that are used in the generation
  -f <fileName>   : Sets the dictionary file name to fileName
-pl is a required parameter.
Example run: 
PassGen -pl 4 -c 0123456789 -f dictionary.txt
This would make a dictionary file called dictionary.txt in the directory PassGen was run from.
dictionary.txt would include all 4 digit pins.

#---Included---#
PassGen:
  PassGenInstall.bash   -> Installer
  PassGenUninstall.bash -> Uninstaller
  README.txt            -> This file
    exec:               -> PassGen's executable folder
      PassGen           -> PassGen(The executable)
    source:             -> The folder containing source files
      argFunctions.cpp  -> Dealing with parameters
      argFunctions.h    -> Dealing with parameters
      includes.h        -> File containing all system-includes
      otherFunc.cpp     -> Other functions
      otherFunc.h       -> Other functions
      PassGen.cpp       -> Main file

#----Notice----#
By using PassGen or its source, you agree that I do not take responsibility to(but not limited to):
-Any illegal actions you take using PassGen
-Any damage done to any system from the use of PassGen, whether it be yours or someone else's
-Any other trouble/issue/etc.
If you decide to distribute any part of PassGen, this section and the author section MUST be included.
PassGen was designed to pentest anything YOU own, and not someone else's.

#-Support/Bugs-#
If you discover any bugs or have questions, please report/ask them at:
Email: epictincangames@gmail.com
Skype: flare.cat

#--Copyright--#
Copyright (c) 2015 ETCG_FlareCat



Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:



The above copyright notice, this permission notice, and the above author section shall be included in
all copies or substantial portions of the Software.



THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
