package cc.ticktalk.ticktalk.model.protocol.types;

public class ChangeGroupUser {
    String groupID;
    String mode;
    String username;
    String nickname;
}
