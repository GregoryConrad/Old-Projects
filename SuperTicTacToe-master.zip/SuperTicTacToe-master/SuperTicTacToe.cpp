//Author: ETCG
//Includes:
#include <iostream>
#include <string>
#include <ctime>
//Namespace:
using namespace std;
//Function Declarations:
void displayBoard(char board[9][9]);
void setBigGrid(int bigGrid[3][3], char board[9][9]);
int thatReallyLongFunctionThatIDontWantToMakeThatChecksIfSomeoneHasWonTheGame(int bigGrid[3][3]);
bool gameOver(char board[9][9], int bigGrid[3][3]);
//Main Function:
int main() {
    //Setup:
    srand(time(0));
    string userOption;
    cout << "Super Tic Tac Toe\nOptions:\n  - \"single\" -> Singleplayer\n  - \"multi\"  -> Multiplayer\n  - \"help\"   -> Help\n"
        << "Please enter an option: ";
    cin >> userOption;
    for (int i = 0; i < userOption.length(); i++) {
        userOption[i] = toupper(userOption[i]);
    }
    bool singleplayer;
    if (userOption == "SINGLE") singleplayer = true;
    else if (userOption == "MULTI") singleplayer = false;
    else {
        cout << "Help Menu:\n"
            << "Singlelayer mode is when you play against the computer\n"
            << "Multiplayer mode is when you play against another human, who is with you (this mode does not use internet)\n"
            << "When asked for coordinates, please enter two numbers seperated by a space.\n"
            << "Enter the numbers in the format of:\nrow column\n"
            << "In singleplayer, you are X, the computer is O. Also, you are refered to as Player 1, and the computer is refered to as Player 2.\n"
            << "In multiplayer, the first player is X, and the second player is O.\n"
            << "Please see the README for more info.\n";
        return 1;
    }   
    char board[9][9]; //Declare board
    for (int a = 0; a < 9; a++) { //Fill board with spaces
        for (int b = 0; b < 9; b++) {
            board[a][b] = ' ';
        }
    }
    int userRow, userCol, user2Row, user2Col, bigGrid[3][3]; //Sets some variables, and an array
    for (int a = 0; a < 3; a++) {
        for (int b = 0; b < 3; b++) {
            bigGrid[a][b] = 0;
        }
    }
    //Gameplay:
    for(;;) {
        displayBoard(board);
        for(;;) { //Gets coords
            cout << "Player 1: Please enter coordinates: ";
            cin >> userRow >> userCol;
            userRow--;
            userCol--;
            if (userRow >= 0 && userCol >= 0) {
                if (userRow < 9 && userCol < 9) {
                    if (board[userRow][userCol] == ' ') {
                        break;
                    }
                    else cout << "Spot already taken!\n";
                }
                else cout << "Values must be less than or equal to 9!\n";
            }
            else cout << "Values must be greater than or equal to 1!\n";
        }
        board[userRow][userCol] = 'X';
        //Fixes a bug:
        if (gameOver(board, bigGrid)) return 0;
        //User2 coords:
        if (singleplayer) {
            user2Row = rand() % 9;
            user2Col = rand() % 9;
            while((board[user2Row][user2Col] != ' ') || (bigGrid[(int)(user2Row/3)][(int)(user2Col/3)] != 0)) {
                user2Row = rand() % 9;
                user2Col = rand() % 9;
            } //Yes, I am aware this is a very bad randomization method.
              //The chances that it will take more than 1 second are EXTREMELY small, so it is fine for now.
        }
        else {
            displayBoard(board);
            for(;;) { //Gets coords
                cout << "Player 2: Please enter coordinates: ";
                cin >> user2Row >> user2Col;
                user2Row--;
                user2Col--;
                if (user2Row >= 0 && user2Col >= 0) {
                    if (user2Row < 9 && user2Col < 9) {
                        if (board[user2Row][user2Col] == ' ') {
                            break;
                        }
                        else cout << "Spot already taken!\n";
                    }
                    else cout << "Values must be less than or equal to 9!\n";
                }
                else cout << "Values must be greater than or equal to 1!\n";
            }
        }
        board[user2Row][user2Col] = 'O';
        displayBoard(board);
        //Now, to see if someone has won (this part of the code sucks):
        if (gameOver(board, bigGrid)) return 0;
        //Thank god that part is done. Phew. Time for the next loop.
    }
}
bool gameOver(char board[9][9], int bigGrid[3][3]) {
    //First, we need to see who has control over what mini grids (if any):
    setBigGrid(bigGrid, board);
    //Next, we need to see if someone has won, via the mini grids:
    int winner = thatReallyLongFunctionThatIDontWantToMakeThatChecksIfSomeoneHasWonTheGame(bigGrid);
    //Now, dealing with the results:
    if (winner == 1) {
        cout << "Player 2 won!\n";
        return true;
    }
    if (winner == 2) { //I wonder why I made 2 player 1, and 1 player 2...Huh...
        cout << "Player 1 won!\n";
        return true;
    }
    if (winner == 3) {
        cout << "There was a tie!\n";
        return true;
    }
    return false;
}
int thatReallyLongFunctionThatIDontWantToMakeThatChecksIfSomeoneHasWonTheGame(int bigGrid[3][3]) {
    //This part checks if someone won in one direction:
    int counterX = 0, counterO = 0;
    for (int col = 0; col < 3; col++) {
        for(int row = 0; row < 3; row++) {
            if (bigGrid[row][col] == 2) counterX++;
            if (bigGrid[row][col] == 1) counterO++;
        }
        if (counterO == 3) return 1;
        else if (counterX == 3) return 2;
        else {counterO = 0; counterX = 0;}   
    }
    //This part checks if someone won in the other direction:
    for (int col = 0; col < 3; col++) {
        for(int row = 0; row < 3; row++) {
            if (bigGrid[col][row] == 2) counterX++;
            if (bigGrid[col][row] == 1) counterO++;
        }
        if (counterO == 3) return 1;
        else if (counterX == 3) return 2;
        else {counterO = 0; counterX = 0;}   
    }
    //Diagnols?
    if ((bigGrid[0][0] == 1 && bigGrid[1][1] == 1 && bigGrid[2][2] == 1) || (bigGrid[2][0] == 1 && bigGrid[1][1] == 1 && bigGrid[0][2] == 1)) {
        return 1;
    }
    if ((bigGrid[0][0] == 2 && bigGrid[1][1] == 2 && bigGrid[2][2] == 2) || (bigGrid[2][0] == 2 && bigGrid[1][1] == 2 && bigGrid[0][2] == 2)) {
        return 2;
    }
    //Now to check to see if there was a tie:
    int tieCounter = 0;
    for (int a = 0; a < 3; a++) {
        for (int b = 0; b < 3; b++) {
            if (bigGrid[a][b] != 0) tieCounter++;
        }
    }
    if (tieCounter == 9) return 3;
    return 0; //Game is still ongoing.
    //Hey, it wasn't as long as I though. The setBigGrid will probably be long though... :(
}
void setBigGrid(int bigGrid[3][3], char board[9][9]) {
    for (int a = 0; a < 3; a++) {
        for (int b = 0; b < 3; b++) {
            //This part checks if someone won a mini tic tac toe in one direction:
            int counterX = 0, counterO = 0;
            for (int col = a*3; col < a*3+3; col++) {
                for(int row = b*3; row < b*3+3; row++) {
                    if (board[row][col] == 'X') counterX++;
                    if (board[row][col] == 'O') counterO++;
                }
                if (counterO == 3) {if (bigGrid[a][b] == 0) bigGrid[a][b] = 1;}
                else if (counterX == 3) {if (bigGrid[a][b] == 0) bigGrid[a][b] = 2;}
                else {counterO = 0; counterX = 0;}   
            }
            //This part checks if someone won in the other direction:
            for (int col = a*3; col < a*3+3; col++) {
                for(int row = b*3; row < b*3+3; row++) {
                    if (board[col][row] == 'X') counterX++;
                    if (board[col][row] == 'O') counterO++;
                }
                if (counterO == 3) {if (bigGrid[a][b] == 0) bigGrid[a][b] = 1;}
                else if (counterX == 3) {if (bigGrid[a][b] == 0) bigGrid[a][b] = 2;}
                else {counterO = 0; counterX = 0;}   
            }
            //Diagnols? -> This part was messed up. Don't copy and paste code kids.
            if ((board[a*3][b*3]=='O' && board[a*3+1][b*3+1]=='O' && board[a*3+2][b*3+2]=='O') || (board[a*3+2][b*3]=='O' && board[a*3+1][b*3+1]=='O' && board[a*3][b*3+2]=='O')) {
                if (bigGrid[a][b] == 0) bigGrid[a][b] = 1;
            }
            if ((board[a*3][b*3]=='X' && board[a*3+1][b*3+1]=='X' && board[a*3+2][b*3+2]=='X') || (board[a*3+2][b*3]=='X' && board[a*3+1][b*3+1]=='X' && board[a*3][b*3+2]=='X')) {
                if (bigGrid[a][b] == 0) bigGrid[a][b] = 2;
            }
            //Now, to see if a user has one based on majority -> This segment may be buggy, not sure:
            counterO = 0;
            counterX = 0;
            for (int c = a*3; c < a*3+3; c++) {
                for (int d = b*3; d < b*3+3; d++) {
                    if (board[c][d] == 'X') counterX++;
                    if (board[c][d] == 'O') counterO++;
                }
            }
            if ((counterO + counterX == 9) && (bigGrid[a][b] == 0) && (counterO > counterX)) bigGrid[a][b] = 1;
            if ((counterO + counterX == 9) && (bigGrid[a][b] == 0) && (counterX > counterO)) bigGrid[a][b] = 2;
            //That was miserable...at least there is copy and paste, from the previous function...
        }
    }
}
void displayBoard(char board[9][9]) {
    for (int i = 0; i < 75; i++)
        cout << endl; //Clears screen
    cout << "Super Tic Tac Toe\n\n\n";
    for (int row = 0; row < 9; row++) {
        for (int i = 0; i < 8; i++) {
            cout << board[row][i];
            if (i % 3 - 2 == 0) cout << " | ";
            else cout << "|";
        }
        cout << board[row][8] << endl;
        if (row%3-2==0) {
            cout << endl;
            if (row != 8) for (int i = 0; i < 21; i++)
                cout << "-";
            cout << endl;
        }
        else cout << "-+-+- | -+-+- | -+-+-";
        cout << endl;
    }
}
