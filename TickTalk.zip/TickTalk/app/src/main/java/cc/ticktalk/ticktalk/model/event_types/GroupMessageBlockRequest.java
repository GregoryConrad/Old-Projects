package cc.ticktalk.ticktalk.model.event_types;

import cc.ticktalk.ticktalk.model.protocol.types.MessageBlockRequest;

public class GroupMessageBlockRequest {
    public MessageBlockRequest request;
    public GroupMessageBlockRequest(MessageBlockRequest request) {
        this.request = request;
    }
}
