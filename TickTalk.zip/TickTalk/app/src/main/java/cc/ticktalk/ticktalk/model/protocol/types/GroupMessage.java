package cc.ticktalk.ticktalk.model.protocol.types;

public class GroupMessage {
    String groupID;
    String id;
    String username;
    String timestamp;
    String replyTo;
    String[][] encryptedMsgData;
}
