package cc.ticktalk.ticktalk.model.protocol.types;

public class MakeGroup {
    String groupName;
    String[] usernames;
}
