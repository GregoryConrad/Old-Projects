package cc.ticktalk.ticktalk.model.protocol.types;

import java.util.HashMap;

public class UserData {
    public String username;
    public String displayName;
    public String picture;
    public String pubKey;
    public String privateKey;
    public String[] rooms;
    public HashMap<String, String>[] groups;
}
