#include "includes.h"

class argFunctions {
public:
	void setValuesArg(char **a, int b);
	void setValuesVMode(bool a);
	bool checkParameter(std::string parameter);
	const char *getValue(std::string parameter);
	void removeValue(std::string parameter);
	int checkDir();
private:
	std::vector<std::string> args;
	bool verboseMode;
};