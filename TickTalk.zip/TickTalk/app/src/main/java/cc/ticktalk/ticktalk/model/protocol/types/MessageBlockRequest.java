package cc.ticktalk.ticktalk.model.protocol.types;

public class MessageBlockRequest {
    String id;
    String lastMessageID;
}
