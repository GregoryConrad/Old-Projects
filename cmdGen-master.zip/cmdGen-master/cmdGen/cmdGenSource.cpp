/*
Name: Single Command Block Command Generator
Description: A Command Generator Used to Combine Multiple Blocks Together (for Minecraft)
Notes:
  - This only works in Minecraft 1.9+, since it uses features introduced in 1.9
  - This is meant to be an installer for some creation you made, but can be used for other purposes.
  - This will overwrite the give output file, and ETCG is not responsible for any data loss.
Author: ETCG
License: MIT
Contact:
  - epictincangames@gmail.com (Email)
  - flare.cat                 (Skype)

Copyright (c) 2016 ETCG

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Input File Format:

<command 1>
<command 2>
...
<command n>

To remove the original command block, change the first instance of "fill ~ ~" in the output to "fill ~ ~-1"
*/

//MinGW to_string patch:
#include <string> //Strings
#include <sstream> //Needed for patch
namespace patch {
    template < typename T > std::string to_string( const T& n ) {
        std::ostringstream ss;
        ss << n;
        return ss.str();
    }
}

//Includes (cont.):
#include <iostream> //In/Out
#include <fstream> //File Reading/Writing
#include <vector> //Array Management

//Namespace:
using namespace std;

//Main:
int main (int argc, char** args) {
	//Start:
	cout << "\nSingle Command Block Command Generator\n\n"
		<< "        (^)_(^)\n"
        << "        [ - - ]\n"
        << "         \\ U /\n"
        << "          \\_/\n\n"
        << "      Created By:\n"
        << " _____ _____ ____ ____ \n"
        << "| ____|_   _/ ___/ ___|\n"
        << "|  _|   | || |  | |  _ \n"
        << "| |___  | || |__| |_| |\n"
        << "|_____| |_| \\____\\____|\n\n";               
		
	//Check to see if the correct amount of args are entered:
	if (argc != 2 && argc != 3) {
		cout << "You did not enter the correct amount of arguments.\n"
			<< "Usage: " << args[0] << " <Input Commands File> <Output Command File>\n"
			<< "If the file name includes a space, include quotes around it.\n"
			<< "If the output file is not given, the resulting command will be written to the console. But, this is not recommended, and a file should be used instead.\n"
			<< "Also, the contents of the output file WILL be overwritten, so be warned.\n"
			<< "Terminating...\n" << flush;
		return 1;
	}

	//Init vector of input file:
	vector<string> infile(0);
	
    //Read file:
	ifstream input(args[1]); //Make file object
	string currLine; //Declares currLine String
	while (getline(input, currLine)) { //Loop to read file
		infile.push_back(currLine); //Add currLine to vector
	}
	input.close(); //Close file
	
	//File check:
	if (infile.size() == 0) {
		cout << "File is empty!\n"
		    << "Terminating..."
		    << endl;
		return 3;
	}
	
	//Info for user:
	cout << "Processing..." << flush;
	
	//Convert file into single command:
	vector<string> command(0); //Init vector of the final command command[0] is start command, command[1] is added commands, command[2] is ending brackets
	command.push_back("/summon FallingSand ~ ~1 ~ {Block:chain_command_block,Data:0,TileEntityData:{auto:1b,Command:fill ~ ~ ~ ~ ~"); //Add initial command
	command[0] += patch::to_string(infile.size()); //Adds number of command blocks to initial command
    command[0] +=  " ~ air},Time:1,DropItem:0"; //Adds second part of initial command
	command.push_back(""); //Adds command[1]
	command.push_back("}"); //Adds and sets original value of command[2]
	for (int i = infile.size()-1; i >= 0; i--) { //Adding in "Passengers":
		command[1] += ",Passengers:[{id:\"FallingSand\",Time:1,DropItem:0,Data:0,TileEntityData:{auto:1b,Command:\"";
		command[1] += infile[i] + "\"}," + ((i == 0) ? "Block:command_block" : "Block:chain_command_block");
		command[2] = "}]" + command[2];
	}
	cout << "done" << endl;
	
	//Output:
	if (argc == 2) { //We are using command prompt
		cout << "Your command:\n\n";
		cout << command[0]
		    << command[1]
			<< command[2]
			<< endl << endl;
	}
	else if (argc == 3) { //We are using file
		ofstream outfile(args[2]);
		outfile << command[0]
			<< command[1]
			<< command[2]
			<< flush;
		outfile.close();
		cout << "Command located in " + (string)(args[2]) + ".\n";
	}
	else { cout << "An unknown error has occurred, please try again." << endl; return 2; } //I put this on one line cause I felt like it :P. How many people will get ticked off?
	
	//Exit:
	return 0;
}