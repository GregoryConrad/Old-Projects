//Dictionary File Generator
//Use for legal purposes only!
//Created by: ETCG_FlareCat (Epic Tin Can Games on youtube(ETCG))

//Includes:
#include "argFunctions.h"
#include "otherFunc.h"
//Namespace:
using namespace std;
//Function Declaration:
int passGen(int argc, char *argv[]);
//Functions:
int main(int argc, char *argv[]) {
	return passGen(argc, argv);
}
int passGen(int argc, char *argv[]) {
	//Creating Objects:
	argFunctions arg;
	otherFunc func;
	//Help stuff:
	if (argc == 1 || arg.checkParameter("-h") || arg.checkParameter("-help")) { 
		func.displayHelp();
		return 1;
	}
	//Dealing with arguments:
	//Setting up some needed stuff:
	arg.setValuesArg(argv, argc);
	bool verboseMode = arg.checkParameter("-v"), noBar = arg.checkParameter("-npb");
	arg.setValuesVMode(verboseMode);
	func.setValuesVMode(verboseMode);
	arg.removeValue("-v");
	arg.removeValue("-npb");
	//Checking the password length:
	if (!arg.checkParameter("-pl")) {
		if (verboseMode) {
			std::cout << "The password length needs to be specified. Please use -h for more info.\nTerminating...\n";
		}
		return -1;
	}
	const int passwordlength = stoi(arg.getValue("-pl")); //Gets password length
	if (!(passwordlength > 0 && passwordlength < 21)) {
		if (verboseMode) {
			std::cout << "Invalid password length. Use -h to see help/correct usage.\nTerminating...\n";
		}
		return -1; //Error code. 
	}
	//Checking directory:
	if (arg.checkDir() != 0) {
		return -1;
	}
	//Dictionary file name set:
	string fileName;
	if (arg.checkParameter("-f")) {
		const char *fileNameTemp = arg.getValue("-f");
		if (fileNameTemp == NULL) {
			if (verboseMode) {
				std::cout << "Incorrect usage of -f. Use -h to see help/correct usage.\nTerminating...\n";
			}
			return -1;
		}
		fileName = fileNameTemp;
	}
	else {
		fileName = "passwords.txt";
	}
	//Setting/checking characters:
	string chars;
	if (!arg.checkParameter("-c")) {
		chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	}
	else {
		const char *temp = arg.getValue("-c");
		if (temp == NULL) {
			if (verboseMode) {
				std::cout << "Incorrect usage of -c. Use -h to see help/correct usage.\nTerminating...\n";
			}
			return -1;
		}
		chars = temp;
	}
	const int numofchars = chars.length();
	//Displayed intro, with verboseMode enabled:
	if (verboseMode) { 
		cout << "Dictionary File Generator\n"
			<< "The characters that are being used to generate the passwords are on the following line.\n"
			<< chars << "\n";
	}
	//Setting up:
	time_t timeStart = time(0);
	ofstream passwords(fileName);/*Creates passwords.txt, and creates the object "passwords" for it. 
	Delete this line if you do not plan on creating a dictionary file, and want to use the passwords for 
	something else.*/
	unsigned long long int loopmax = 1;
	for (int loopmaxgen = 0; loopmaxgen < passwordlength; loopmaxgen++) {
		loopmax *= numofchars; //This loop just figures out how long the password generation should go on for.
	}
	int numcombo[20] = { 0 }, whichPartToPrint = 0, progressCheck = 0, buildcounter = 0, numcomboadd = 0; 
	/*Initializes all the values in numcombo to 0, and sets a few other variables. numcombo is an array that 
	stores a passwords numeric form, that is eventually converted to the actual password.*/
	unsigned long long int progressAmount = loopmax / 50; /*For the custom progress bar, takes the loopmax 
										and divides it by 50, which will make 50 pieces for the progress bar.*/
	string spinningWheel = "|/-\\", currentPassword;
	//Generation of passwords begins here.
	if (verboseMode) cout << "\nGenerating dictionary file...\n";
	for (unsigned long long int loopcounter = 0; loopcounter < loopmax; loopcounter++)
	{
		//Password builder begins here.
		for (currentPassword = ""; buildcounter < passwordlength; buildcounter++) {
			currentPassword += chars[numcombo[buildcounter]];
		} //Takes numerical value from numcombo, and converts it into a password stored in passwords.txt.
		passwords << currentPassword << endl; /*Prints the password to the file. Change or delete this line of
		code if you want something else to be done with the passwords.*/
		//Password builder ends here.

		//Password adder:
		for (buildcounter = 0; numcombo[numcomboadd] == numofchars - 1; numcomboadd++) { 
			numcombo[numcomboadd] = 0; //deals with carry-over
		}
		numcombo[numcomboadd]++;
		numcomboadd = 0;
		//Progress bar:
		if (!noBar) {
			if (loopcounter >= progressCheck*(progressAmount / 2)) {
				progressCheck++; //Checking to see if progressCheck needs to be changed.
			}
			if (loopcounter % 50000 == 0) //Refreshes progress bar once every 50,000 loops, which
			{							  //should be a good speed on the average system.
				cout << "\r" << "[" << func.progressBar(progressCheck) //Prints progress bar
					<< spinningWheel[whichPartToPrint] << setw(53 - (func.progressBar(progressCheck).length()))
					<< "] (" << progressCheck - 1 << "% done)" << flush;
				whichPartToPrint++; //This line and the next cause the wheel 
				whichPartToPrint %= 4; //to spin at the end of the progress bar
			}
		}
	}
	//Ending:
	if (!noBar) {
		cout << "\r[|||||||||||||||||||||||||||||||||||||||||||||||||||] (100% done)\n"; //Fixes a display bug.
	}
	if (verboseMode) {
		time_t timeEnd = time(0);
		cout << "\nThe generation has succeeded. The dictionary file " << fileName << " is located in " << func.getcwd_string() 
			<< "\n" << timeEnd - timeStart << " second(s) have elapsed.\n";
	}
	passwords.close(); /*Closes passwords file. Delete this line if you are using the password generation for
	something else.*/
	return 0; //Returns that the program worked, and quits.
}